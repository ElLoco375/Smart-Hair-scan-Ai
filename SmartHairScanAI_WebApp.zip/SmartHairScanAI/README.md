# Smart HairScan AI — Web App

## Keperluan
- Python 3.10 atau lebih baharu
- Sambungan internet untuk pemasangan pakej kali pertama

## Pemasangan
```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Pasang pakej:
```bash
pip install -r requirements.txt
```

Jalankan:
```bash
streamlit run app.py
```

Aplikasi akan dibuka di `http://localhost:8501`.

## Model YOLO
Aplikasi membaca model `best.pt` di folder projek. Model perlu dilatih
menggunakan dataset berlabel yang sesuai. Nama kelas yang disyorkan:
- `long_hair`
- `short_hair`
- `colored_hair`
- `natural_hair`

Model perlu dilatih dan diuji pada keadaan sebenar sekolah. Pengesanan
panjang rambut memerlukan definisi operasi yang konsisten (contohnya
melepasi garisan kolar atau ukuran yang ditetapkan sekolah), sudut kamera
yang terkawal dan semakan manusia.

Contoh arahan latihan selepas dataset YOLO disediakan:
```bash
yolo detect train data=data.yaml model=yolo11n.pt epochs=100 imgsz=640
```
Fail terlatih biasanya berada di:
`runs/detect/train/weights/best.pt`

Salin fail tersebut ke folder projek dan namakan `best.pt`.

## Nota penting
- Aplikasi ini ialah prototaip, bukan sistem disiplin automatik.
- Model tidak disertakan kerana ia perlu dilatih dan disahkan dengan dataset
  yang dibenarkan untuk kegunaan sekolah.
- Analisis warna kasar dalam aplikasi bukan pengelas rambut.
- Keputusan mesti disahkan oleh guru; jangan kenakan tindakan disiplin
  berdasarkan skor AI semata-mata.
- Gunakan kawalan akses, persetujuan/kelulusan yang sesuai, dan dasar
  penyimpanan data pelajar.
