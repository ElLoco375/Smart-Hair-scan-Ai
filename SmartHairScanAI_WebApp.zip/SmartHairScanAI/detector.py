from pathlib import Path
import numpy as np
from PIL import Image
import streamlit as st

MODEL_PATH = Path(__file__).with_name("best.pt")

@st.cache_resource
def load_yolo_model():
    if not MODEL_PATH.exists():
        return None
    try:
        from ultralytics import YOLO
        return YOLO(str(MODEL_PATH))
    except Exception:
        return None

def analyze_image(pil_image, confidence=0.40):
    """
    Expects a custom YOLO model with classes such as:
    long_hair, colored_hair, short_hair, natural_hair.
    The exact class names are read from the trained model.
    """
    model = load_yolo_model()
    detections = []
    annotated = pil_image.copy()
    long_status = "Belum dapat ditentukan"
    color_status = "Belum dapat ditentukan"
    notes = []

    if model is None:
        notes.append(
            "Model best.pt belum dipasang. Pengesanan AI rambut panjang "
            "dan pengesanan objek berasaskan YOLO belum aktif."
        )
        return {
            "model_ready": False,
            "detections": detections,
            "annotated": annotated,
            "long_status": long_status,
            "color_status": color_status,
            "notes": " ".join(notes)
        }

    result = model.predict(source=pil_image, conf=confidence, verbose=False)[0]
    names = model.names
    for box in result.boxes:
        class_id = int(box.cls[0])
        class_name = str(names[class_id]).lower().replace(" ", "_")
        score = float(box.conf[0])
        detections.append({"name": class_name, "confidence": score})

    long_found = any(
        ("long" in d["name"] or "panjang" in d["name"])
        and "not_long" not in d["name"]
        for d in detections
    )
    short_found = any(
        "short" in d["name"] or "pendek" in d["name"]
        for d in detections
    )
    colored_found = any(
        "colored" in d["name"] or "berwarna" in d["name"]
        for d in detections
    )
    natural_found = any(
        "natural" in d["name"] or "semula_jadi" in d["name"]
        for d in detections
    )

    if long_found:
        long_status = "Petunjuk rambut panjang dikesan"
    elif short_found:
        long_status = "Petunjuk rambut pendek dikesan"
    else:
        long_status = "Tiada kelas panjang/pendek dikesan"

    if colored_found:
        color_status = "Petunjuk rambut berwarna dikesan"
    elif natural_found:
        color_status = "Petunjuk warna semula jadi dikesan"
    else:
        color_status = "Tiada kelas warna dikesan"

    annotated = Image.fromarray(result.plot()[:, :, ::-1])
    notes.append(
        "Keputusan model ialah saringan awal. Guru perlu menyemak gambar "
        "dan mengesahkan keputusan mengikut peraturan sekolah."
    )

    return {
        "model_ready": True,
        "detections": detections,
        "annotated": annotated,
        "long_status": long_status,
        "color_status": color_status,
        "notes": " ".join(notes)
    }

def estimate_unusual_color(pil_image):
    """
    Optional rough image-colour indicator. It is NOT a hair classifier.
    It should only be used as a prompt for human review, not as a finding.
    """
    img = np.array(pil_image.convert("RGB"))
    h, w = img.shape[:2]

    # Central upper region as a rough region of interest.
    crop = img[int(h * 0.05):int(h * 0.48),
               int(w * 0.20):int(w * 0.80)]
    if crop.size == 0:
        return None

    import cv2
    hsv = cv2.cvtColor(crop, cv2.COLOR_RGB2HSV)
    saturation = hsv[:, :, 1]
    hue = hsv[:, :, 0]
    # Exclude very dark and very bright pixels; still not hair-specific.
    value = hsv[:, :, 2]
    valid = (value > 35) & (value < 235)
    if valid.sum() == 0:
        return None

    vivid = (saturation > 100) & valid
    ratio = float(vivid.sum() / valid.sum())
    return {
        "vivid_pixel_ratio": ratio,
        "possible_vivid_color": ratio > 0.12,
        "warning": (
            "Petunjuk warna imej sahaja; bukan pengesanan rambut. "
            "Pencahayaan, pakaian atau latar belakang boleh mempengaruhi bacaan."
        )
    }
